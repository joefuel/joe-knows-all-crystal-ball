import { useState } from 'react';

export default function Home() {
  const [question, setQuestion] = useState('');
  const [answer, setAnswer] = useState('');

  const askQuestion = async () => {
    const res = await fetch('/api/ask', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ question }),
    });
    const data = await res.json();
    setAnswer(data.answer);
  };

  return (
    <div style={{ textAlign: 'center', padding: '2rem' }}>
      <h1>Joe Knows</h1>
      <img src="/crystal_ball.gif" alt="Crystal Ball" width="200" />
      <div>
        <input
          type="text"
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          placeholder="Ask anything..."
          style={{ width: '300px', padding: '0.5rem', margin: '1rem' }}
        />
        <button onClick={askQuestion}>Ask</button>
      </div>
      {answer && (
        <div style={{ marginTop: '2rem', fontSize: '1.2rem' }}>
          <strong>Answer:</strong> {answer}
        </div>
      )}
    </div>
  );
}
